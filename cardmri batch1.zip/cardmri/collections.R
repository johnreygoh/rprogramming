# vector
vector1 = c(1,2,3,4,5,"hello","a","b","c")
print(vector1)
print(vector1[8])

# list
mycar = list(cbrand="toyota",cyear=2023,ccolor="red")
print(mycar)
print(mycar["cbrand"])

# data frame
df = data.frame(name=c("diana","maria","joseph"),
                age=c(21,22,"secret"), 
                office=c("makati","manila","laguna"))
print(DF)

# matrix 
matrix1 = matrix(c(1,2,3,4,5,"yes"),nrow = 2, ncol = 3)
print(matrix1)





