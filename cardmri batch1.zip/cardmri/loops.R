# while loop
# ctr = 15
# while(ctr<=10){
#   print(paste0(ctr,".hello"))
#   ctr = ctr + 1
# }

# multiplication table
# v = 3
# 3 x 0 = 0
# 3 x 1 = 3
# 3 x 10 = 30

# v = 5
# ctr = 0
# while(ctr<=10){
#   p = v * ctr
#   print(paste0(v," x ",ctr," = ",p))
#   ctr = ctr + 1
# }

# quiz
# 2020-1960
# y = 2020
# while(y>=1960){
#   if (y>1985 || y<1980) {
#     print(y)
#   }
#   
#   y=y-1
# }

#2023-1950, every 5
# y = 2023
# while(y>=1960){
#   print(y)
#   y=y-5
# }

# do-while
ctr = 19
repeat{
  print(paste0(ctr,".hi"))
  ctr = ctr + 1
  if(ctr>11){
    break
  }
}











