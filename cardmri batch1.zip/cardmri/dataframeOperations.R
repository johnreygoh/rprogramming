# dataframe operations

# create
names = c("Annie","Howard","Mike")
ages = c(23,45,34)

df = data.frame(Name = names, Age = ages)
print(df)
df

# read csv to df
df2 = read.csv("cardmri/titanic.csv")

# limit col
df3 = df2[c("Passenger.Name","Gender","Age")]

head(df3) #first 6
tail(df3) #last 6

# column names
colnames(df2)

# get a numeric column, perform aggregation
ages = df2[c("Age")]
vec_ages = as.vector(unlist(ages))
sum_of_ages = sum(vec_ages,na.rm = T)
avg_age = round(mean(vec_ages,na.rm = T),digits = 1)
max_age = max(vec_ages,na.rm = T)
min_age = min(vec_ages,na.rm = T)

summary(df2)














