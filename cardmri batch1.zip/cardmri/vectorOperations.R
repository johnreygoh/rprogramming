# vector operations
branches = c("USA","Philippines","Australia")

print(branches)
print(branches[2])
print(sort(branches))
print(sort(branches,decreasing = T))
print(length(branches))

branches=append(branches,"Russia")
branches=append(branches,c("Germany","India"))
print(branches)

branches2 = c("Iceland","Vietnam")
#branches3 = c(branches,branches2)
branches = c(branches,branches2)
print(branches)

#remove items
branches = branches[ ! branches == "India" ]
print(branches)

branches = branches[!branches %in% c("USA","Russia")]
print(branches)

branches = branches[-c(1,2)]
print(branches)

branches = branches[-c(length(branches))]
print(branches)

salaries = c(90000,98000,76000,87000)
print(min(salaries))
print(max(salaries))
print(sum(salaries))
print(mean(salaries))








