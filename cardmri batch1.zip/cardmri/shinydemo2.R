library(shiny)

ui <- fluidPage(
  
  titlePanel("Shiny app demo 2"),
  
  sidebarLayout(
    
    sidebarPanel(
      textInput("n",label = "name"),
      selectInput("dd",label = "schedule",choices = c("AM","PM","EVE")),
      radioButtons("r",label = "gender", choices = c("male","female")),
      h5("Are you going?"),
      checkboxInput("cc",label = "yes")
    ),
    mainPanel(
      h3("Answer"),
      verbatimTextOutput("answer")

    )
    
  )
  
)

server <- function(input, output) {
  
  output$answer = renderText({
    
    name = input$n
    sched = input$dd
    gender = input$r
    going = ifelse(input$cc,"yes","no")
    toupper(paste0(name," ",sched," ",gender," ",going))
  })
}

shinyApp(ui, server)