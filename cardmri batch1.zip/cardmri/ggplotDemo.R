library(ggplot2)

#ggplot demo
df = read.csv("cardmri/titanic.csv")

# scatterplot
ggplot(data = df,aes(x=Age,y=Age.Group)) +
  geom_point(color = "blue",size = 1) +
  geom_smooth(method = "lm",color = "red", se = F) + 
  labs(title = "Age by Age Group Scatter Plot",
       subtitle = "Titanic Dataset", 
       x = "Passenger Age",
       y = "Age Groups",
       )

theme_dark()

# create pic file
ggsave(filename = "cardmri/charts/scatter_ageByAgegroup.png", 
       height = 3, width = 6, dpi = 300 )




