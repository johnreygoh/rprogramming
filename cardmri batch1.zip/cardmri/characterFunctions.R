# character funtions
x = "pRoGramMiNg"
print(toupper(x))
print(tolower(x))
print(nchar(x))
print(substr(toupper(x),1,3))
print(sub("m","f",x))
print(gsub("m","f",x,ignore.case = T))

xx = "are you hungry?"
splitxx = strsplit(xx," ")
class(splitxx)
print(splitxx[[1]][2])











