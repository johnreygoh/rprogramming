# vector operations
v1 = c(10,20,30,40,50,60,70,80,90,100,110)

lastcount = length(v1)
thirdfromlast = lastcount-2

#indexing 
print(v1[1:3])
print(v1[thirdfromlast:lastcount])

if (lastcount%%2 == 1) {
  mid = ceiling(lastcount / 2)
  print(v1[mid])
}else{
  mid1 = lastcount / 2
  mid2 = (lastcount / 2) + 1
  print(v1[mid1:mid2])
}

# rounding numbers
n = 19.7898
print(round(n,digits = 2))
print(ceiling(n)) #whole number not lower than itself
print(floor(n)) #whole num not greater than itself

# filtering
lessthan50 = v1 < 50 #selection
filtered = v1[lessthan50]
print(filtered)

#get the position based on condition
gt60 = which(v1 > 60)
print(gt60)

#quiz
v2 = c(50,10,90,40,20,30,60,80,70,100)

# sort first 
# then get values less than or equal to 50
# get mid

sorted = sort(v2)
filter50 = sorted[sorted <= 50]
if (length(filter50) %% 2 == 1) {
  mid = ceiling(length(filter50)/2)
  print(filter50[mid])
}else{
  m1 = length(filter50)/2
  m2 = m1 + 1
  print(filter50[m1:m2])
}









