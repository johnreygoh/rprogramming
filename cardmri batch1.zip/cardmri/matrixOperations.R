# matrices
m1 = matrix(1:12, nrow = 4, ncol = 3, 
            dimnames = list(c("row1","row2","row3","row4"),
                            c("col1","col2","col3")))
print(m1)

# access matrix[row,col]
print(m1[3,2])
print(m1[3,]) #whole row 3
print(m1[,1]) #whole col 1

# arithmetic
m2 = matrix(1:8,nrow = 2)
m3 = matrix(8:15,nrow = 2)

print(m2)
print(m3)

m4 = m2 + m3
print(m4)

library(matrixStats)

row_sums = rowSums(m2)
col_sums = colSums(m2)
row_means = rowMeans(m2)
col_means = colMeans(m2)
row_max = rowMaxs(m2)
row_min = rowMins(m2)
col_max = colMaxs(m2)
col_min = colMins(m2)













