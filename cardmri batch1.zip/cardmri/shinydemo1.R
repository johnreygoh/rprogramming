library(shiny)

library(shiny)

ui <- fluidPage(
  
  textInput("txt_fn",label = "enter first name:"),
  textInput("txt_ln",label = "enter last name:"),
  verbatimTextOutput("lbl_fullname")
  
)

server <- function(input, output) {
  
  output$lbl_fullname = renderText({
    
    fn = input$txt_fn
    ln = input$txt_ln
    toupper(paste0(fn," ",ln))
    
  })

}

shinyApp(ui, server)
