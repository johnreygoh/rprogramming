# Shiny app to display a CSV file in a table
library(shiny)

ui <- fluidPage(
  titlePanel("Display CSV in a Table"),
  sidebarLayout(
    sidebarPanel(
      fileInput("csv_file", "Choose a CSV file:")
    ),
    mainPanel(
      textOutput("rec_count"),
      tableOutput("table")
    )
  )
)

server <- function(input, output) {
  
  # Read the CSV file when uploaded
  dataset <- reactive({
    req(input$csv_file)  # Ensure a file is selected
    read.csv(input$csv_file$datapath)
  })
  
  # find record count
  dataset_count <- reactive({
    req(input$csv_file)  # Ensure a file is selected
    c = nrow(read.csv(input$csv_file$datapath))
    toupper(paste0("Record: ",c))
  })

  # Render the text
  output$rec_count <- renderText({
    dataset_count()
  })

  # Render the table
  output$table <- renderTable({
    dataset()
  })
  
  
}

shinyApp(ui, server)
