# view all datasets
# data()

df = mtcars 
write.csv(df,file="cardmri/mtcars.csv")
