# string r demo
library(stringr)
s = "Hello, World!"
c = str_length(s)
u = str_to_upper(s)
l = str_to_lower(s)
ss = str_sub(s,start = 1,end = 3)
sp = str_split(s,pattern = ",")
sr = str_replace_all(s,"World","Mars")
fi = str_detect(s,"Hello")