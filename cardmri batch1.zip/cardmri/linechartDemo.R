# line chart

library(ggplot2)
df = read.csv("cardmri/mtcars.csv")

# HP over time
ggplot(data = df,aes(x=mpg,y=hp)) +
  geom_line(color="red",size = 1.2) +
  labs(title = "line chart of mpg by hp",
       x = "mpg",y="HP")
theme_minimal()













