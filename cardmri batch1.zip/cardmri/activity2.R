# activity2

# form
# enter first name: ???
# enter last name: ???
# rate per day(PHP): ???
# days worked: ???
# outside NCR[y/n]: ??
# night sched [y/n]: ??

# if outside NCR np +1000/day
# if night np +200/day

# create 1 function that accepts 6 params and 
# displays the ff:
# ANA CRUZ (NET PAY: PHP68000)

# runnable function from another script

getpay = function(firstname,lastname,rateperday,days,outsideNCR,night){
  fulln = toupper(paste0(firstname," ",lastname))
  basicpay = rateperday * days
  isoutside = outsideNCR
  isnight = night
  plus1 = 0
  plus2 = 0
  if(isoutside=="y") {
    plus1 = days * 1000
  }
  if(isnight=="y") {
    plus2 = days * 200
  }
  np = basicpay + plus1 + plus2
  print(paste0(fulln," (NET PAY: PHP",np,")"))
}

# input
f = readline(prompt = "enter first name: ")
l = readline(prompt = "enter last name: ")
r = as.numeric(readline(prompt = "enter rate per day: "))
d = as.numeric(readline(prompt = "enter number of days: "))
o = readline(prompt = "outside NCR?[y/n]: ")
n = readline(prompt = "night?[y/n]:")

getpay(f,l,r,d,o,n)














