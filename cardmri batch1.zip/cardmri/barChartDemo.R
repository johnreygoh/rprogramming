# bar chart demo
library(ggplot2)

df = read.csv("cardmri/superstore.csv")

# counts of transactions per region
ggplot(data=df,aes_string(x="Region")) +
  geom_bar(color="blue",fill="blue") + 
  labs(title = "Transactions by Region")
theme_dark()

# create pic file
ggsave(filename = "cardmri/charts/bar_regioncount.png", 
       height = 3, width = 6, dpi = 300 )






