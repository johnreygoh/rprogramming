df = read.csv("cardmri/superstore.csv")
# first class shipmode sales.csv
# # ship mode, category, sales, quantity, profit
fclass = df[df$Ship.Mode=="First Class",]
fclass_sel_cols = fclass[c("Ship.Mode", "Category", 
                           "Sales", "Quantity", "Profit")]

write.csv(fclass_sel_cols,
          file = "cardmri/reports/first class shipmode sales.csv",
          row.names = F)
# technology category profits.csv
# # category, subcat, sales, profit
techcat = df[df$Category=="Technology",]
techcat_sel_cols = techcat[c("Category","Sub.Category","Sales", "Profit")]

write.csv(techcat_sel_cols,
          file = "cardmri/reports/technology category profits.csv",
          row.names = F)

# city sales.csv
# # aggregation by city and sales

city_agg = aggregate(df$Sales,by=list(df$City),FUN = sum)
#city_agg_sorted = city_agg[order(-city_agg$Sales)]

write.csv(city_agg,
          file = "cardmri/reports/city sales.csv",
          row.names = F)

# consumer targeted sales.csv
# # region, city, sales 
consum_seg = df[df$Segment=="Consumer",]
consum_seg_sel_cols = consum_seg[c("Segment","Region","City","Sales")]

write.csv(consum_seg_sel_cols,
          file = "cardmri/reports/consumer targeted sales.csv",
          row.names = F)


