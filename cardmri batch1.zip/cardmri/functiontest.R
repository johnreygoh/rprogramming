#function test

source("cardmri/customfunctions.r")
print(greetme("aling","azon"))

greetme2("king","lion")

print(getnetpay(80000,10,2000,2000))
print(sum_all(10,20,30,40,50))
