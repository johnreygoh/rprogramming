# qplot

library(ggplot2)
df = read.csv("cardmri/mtcars.csv")

qplot(x = as.factor(cyl), data = df, geom = "bar", color = "red")





