# variables and data types
bb=12
class(bb)
bb="12"
class(bb)
bb=34.5
class(bb)
print("test1")

