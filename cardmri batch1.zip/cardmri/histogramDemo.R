# histogram chart demo
library(ggplot2)
df = read.csv("cardmri/mtcars.csv")

# car miles per gallon
ggplot(data=df,aes(x=mpg)) +
  geom_histogram(color="red",fill="red",binwidth = 0.6) + 
  labs(title = "Histogram of car mpg")
theme_dark()

# create pic file
ggsave(filename = "cardmri/charts/histogram_carmpg.png", 
       height = 3, width = 6, dpi = 300 )
