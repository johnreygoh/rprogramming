# get user input
fn = readline(prompt = "enter first name:")
ln = readline(prompt = "enter last name:")
age = readline(prompt = "age this year:")

print(paste0(fn," ",ln," ",age))

