# dplyr demo
df = read.csv("cardmri/superstore.csv")

# aggregation 
library(dplyr)

result = df %>% 
  group_by(Region) %>%
  summarise(totalsales = sum(Sales),
            avgsales = mean(Sales),
            maxsales = max(Sales)) %>%
  filter(totalsales>10000)

# show df
result

