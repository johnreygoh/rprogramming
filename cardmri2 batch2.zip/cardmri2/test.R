fn = "kevin"
ln = "reyes"
print(paste0(fn," ",ln))