# activity 5
# prod name: table
# manufac date: 2007-9-7
# branch origin: baguio
#
# generate product code
# TAB-BAG2007
#
# create a function to accept 
# 3 params and generate 
# prod code
library(lubridate)
createprodcode = function(pname,myear,branch){
  p = substr(pname,1,3)
  b = substr(branch,1,3)
  y = as.character(year(ymd(myear)))
  
  return(toupper(paste0(p,"-",b,y)))
}

p = readline(prompt = "prod name: ")
m = readline(prompt = "manufacture date: ")
b = readline(prompt = "branch: ")

print(createprodcode(pname = p,myear = m,branch = b))











