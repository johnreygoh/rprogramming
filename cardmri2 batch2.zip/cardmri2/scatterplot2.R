# ggplot2
library(ggplot2)

# scatterplot
df = mtcars

ggplot(data = df, aes(x = hp,y = mpg)) +
  geom_point(color = "blue", size = 3) +
  labs(title = "Cars Horsepower by Miles per Gallon",
       x = "horsepower",
       y = "miles per gallon") +
  theme_minimal()


ggsave(filename = "cardmri2/charts/HPbyMPG.png",
       width = 6,
       height = 4,
       dpi = 300)




