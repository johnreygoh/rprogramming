# lubridate demo
library(lubridate)

# current date
now()
today()

# string -> convert to date
s = "2020/2/1"
s1 = "2/3/2010"
s2 = "13/4/2010"
s3 = "April 3, 2020"
s4 = "2020 May 4"

da = ymd(s)
class(da)
da1 = dmy(s1)
da2 = dmy(s2)
da3 = mdy(s3)
da4 = ymd(s4)

# extract elements
year(da4)
month(da4)
day(da4)

# add / subtract dates
# 5 days from now
print(today() - days(5))
# 5 years from now
print(today() + years(-5))
# 2yrs 10mos 5days
print(today() + years(2) + months(10) + days(5))

d1 = ymd("2018-1-2")
d2 = today()

# days difference
difftime(d2,d1,units = "days")


