# dataframe practice
df = read.csv("cardmri2/superstore.csv")

# max.print
options(max.print = 1000000)

# data prep
# eda
print(colnames(df))
print(str(df))
print(summary(df))

# col stats
# regions
print(paste0("rec count:",length(df$Region)))
uq_count = length(unique(df$Region))
print(paste0("unique rec count:",uq_count))
print(paste0(unique(df$Region)))

southreg = length(df[df$Region == "South",]$Region)
westreg = length(df[df$Region == "West",]$Region)
eastreg = length(df[df$Region == "East",]$Region)
centralreg = length(df[df$Region == "Central",]$Region)

print(paste0("south:",southreg,", west:",westreg,
             ", east:",eastreg,", central:",centralreg))

# count all unique values
print(table(df$Region))

# total sales
ts = round(sum(df$Sales),digits = 2)
print(paste0("total sales:",ts))

# sales per region
dfsouth = df[df$Region=="South",]
print(paste0("south sales: ",round(sum(dfsouth$Sales),digits = 2)))


# aggregation
# group->function
regsales = aggregate(df$Sales, 
                     by = list(df$Region), 
                     FUN = function(x) 
                       c(Sales=sum(x), 
                         Average=mean(x),
                         MaxSales=max(x)))

colnames(regsales) = c("Region","")
print(regsales)
# write to csv
write.csv(x = regsales, 
          file = "cardmri2/regionsales.csv", 
          row.names = F)

# adding computed column
mydf = df[c("Region","Category","Sales","Quantity")]
head(mydf)

mydf$mydisc = ifelse(mydf$Region=="South",2,5)
head(mydf)

# sales = (unitprice - discount) * quantity

mydf$unitprice = mydf$Sales / mydf$Quantity
mydf$baseprice = mydf$unitprice + mydf$mydisc

head(mydf)
write.csv(x=mydf,
          file = "cardmri2/salesdiscreport.csv",
          row.names = F)



