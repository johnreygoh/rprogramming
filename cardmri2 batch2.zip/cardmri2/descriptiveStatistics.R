# descriptive statistics
# sum, mean, median ,count, mode, max, min
df = read.csv("cardmri2/titanic.csv")

ages = na.omit(df$Age) # numeric vector

sum(ages)
mean(ages)
max(ages)
min(ages)
length(ages)
length(unique(ages))
median(ages)

summary(ages)
table(ages)
# mode = value that appeared most often
# names(sort(-table(ages)))[1]
getmode = function(v){
  return(names(sort(-table(v)))[1])
}

getmode(v = df$Home.Country)

# range, variance, standard deviation
# range
range(ages)
var(ages)
sd(ages)

# skewness
# which is more? lower numbers or high numbers
# positive = more right (more high numbers)
# negative = more left (more low numbers)
# zero skewness = normal distrubution
# install.packages("moments")
library(moments)
skewness(ages)

# kurtosis
# "peakiness"
# extreme values
# base 3
# leptokurtic = if>3 more extreme values, higher peaks
# platykurtic = if<3 flat peaks
# mesokurtic = if = 3 standard distribution
kurtosis(ages)









