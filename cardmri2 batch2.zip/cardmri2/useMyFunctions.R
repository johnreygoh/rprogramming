# use my functions
source("cardmri2/customFunctions.r")

greetme()
n = getnetpay(monthlysalary = 78000,
          nummonths = 2,
          total_deductions = 5000)

print(n)

x = getSumMean(4,4,4,4)
print(x$mysum)
print(x$mymean)



