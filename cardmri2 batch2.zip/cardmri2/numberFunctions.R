# number functions
a = 24.2678

# rounding 
r = round(a,digits = 2)

# floor and ceiling
f = floor(a)
c = ceiling(a)

# sq rt
sq = sqrt(100)

# exponent
ex = 100^2

# get absolute
neg = -4
abs = abs(neg)

# + - * /
# %%  =  modulus division (remainder)
m = 100 %% 2

# vector
v = c(100,200,300,400,500)

s = sum(v)
me = mean(v)
max = max(v)
min = min(v)
co = length(v)









