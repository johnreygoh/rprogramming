# data types
# character, integer, numeric
# vector, list, matrix, data frame
# date
# logical (boolean,T or F)

a = 13
class(a)
b = 13.6
class(b)
c = 13L
class(c)
c = "hi"
class(c)
d = T
class(d)

# collections
# vector, same types
v = c(1,2,3,F,F,T,F,"hello")
print(v)
class(v)

# list
# key-value
l = list("name"="diana","office"="laguna","age"=59,"married"=F)
print(l)
class(l)

# matrix
# rectangular plot, cols and rows
v2 = c(2,4,5,6,9,45,34,12,"none")
# m = matrix(1:12,nrow = 4,ncol = 3)
m = matrix(data = v2,nrow = 4,ncol = 3)
print(m)
class(m)

# data frame
# create
n = c("george","fina","ryan","hannah","julie")
s = c(89,97,97,95,88)
su = c("math","math","math","math","math")
df1 = data.frame(names = n,scores = s, subject = su)
df1
class(df1)

# test if a variable is a spec type
g = "56"
is.numeric(g)
is.character(g)
is.integer(g)

# explicit conversion / coersion
g = as.numeric(g)
class(g)
g = as.integer(g)
class(g)
g = as.character(g)
class(g)

v3 = c(2,4,6,7)
is.numeric(v3)
class(v3)
v3 = as.character(v3)
is.numeric(v3)
class(v3)






















