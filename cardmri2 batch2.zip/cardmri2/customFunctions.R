# custom functions
# action
greetme = function(){
  print("good am")
}

# return value
greetme2 = function(){
  x = "good am 2"
  return(x)
}

getnetpay = function(monthlysalary,nummonths=10,total_deductions){
  np = (monthlysalary * nummonths) - total_deductions
  return(np)
}

sum_all = function(...){
  # items = list(...)
  # answer = sum(unlist(items))
  # return(answer)
  return(sum(unlist(list(...))))
}

getSumMean = function(...){
  list1 = list(...)
  items = unlist(list1)
  s = sum(items)
  m = mean(items)
  return(list(mysum=s,mymean=m))
}











