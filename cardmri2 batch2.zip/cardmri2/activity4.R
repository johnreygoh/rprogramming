# activity 4

# input, compute and display
# 
# enter product name: chair
# enter price per item: 5000
# enter quantity sold: 10
#
# enter another item[y/n]? : n
#
# show data frame
# total sales = 
# total items sold = 
# highest sales = 
# lowest sales = 

# 4 vectors initialized with null
vprod = NULL
vprice = NULL
vqty = NULL
vsales = NULL
# 4 inputs + 1 compute
iprod = ""
iprice = 0
iqty = 0
again = ""
salesperprod = 0
# 4 answers
tsales = 0
tqty = 0
hisales = 0
losales = 0
repeat{
  iprod = readline(prompt = "prod name:" )
  iprice = as.numeric(readline(prompt = "price: "))
  iqty = as.numeric(readline(prompt = "quantity: "))
  again = readline(prompt = "again[y/n]?: ")
  
  vprod = append(vprod,iprod)
  vprice = append(vprice,iprice)
  vqty = append(vqty,iqty)
  salesperprod = iprice * iqty
  vsales = append(vsales,salesperprod)
  
  if (again=="n") {
    break
  }
}

df = data.frame(product=vprod,
                price=vprice,
                quantity=vqty,
                sales=vsales)
print(df)

tsales = sum(vsales)
tqty = sum(vqty)
hisales = max(vsales)
losales = min(vsales)
print(paste0("total sales: ",tsales))
print(paste0("total quantity: ",tqty))
print(paste0("highest sales: ",hisales))
print(paste0("lowest sales: ",losales))





















