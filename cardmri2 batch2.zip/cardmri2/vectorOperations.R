# vector operations

# create
v1 = c(1,2,3,4,5)
v2 = c(10,20,30,40,50)
v3 = c("january","february","march","april","may","june")

# vectorized operations
length(v1)
sum(v1)
mean(v1)
max(v1)
min(v1)
toupper(v3)
length(v3)
toupper(substr(v3,1,3))

# accessing
v2[1]
v3[length(v3)]

#popquiz get the mid value
# even = get 2 mid values
# odd = get mid
# %%
if (length(v3) %% 2 == 1) {
  #odd, get mid item
  v3[ceiling(length(v3)/2)]
  
}else{
  #even, get 2 mid items
  n1 = length(v3)/2
  n2 = n1 + 1
  v4 = c(v3[n1],v3[n2])
  v4
}

# operations on multiple vectors
price1 = c(400,500,300,250,1000)
price2 = c(1000,2000,3000,4000,5000)
qty = c(2,3,5,6,7)
disc = c(8,9,6,5,4)

price3 = price1 + price2
price3 
discprice = price3 - disc
discprice
totalprice = price3 * qty
totalprice

# slicing and filtering
v1[1:3]
v1[3:5]
v1[(length(v1)-2):length(v1)]

v2 = v2[v2 < 30]
v2

# sorting
sort(v3,decreasing = T)
sort(v3,decreasing = F)


v3 = v3[v3 != "april" & v3 != "may" & v3 != "march"]
v3

# handling NA
age = c(34,45,56,76,NA,32,NA,NA)
length(age)
sum(age,na.rm = T)
max(age,na.rm = T)

age[!is.na(age)]
age[complete.cases(age)]

# add or remove item in vector
age = append(age,66)
age
age = age[age!=66]
age





