# lookup demo

df = data.frame(products = c("chair","table","tv"),
                prices = c(5000,34000,38000))

getproductprice = function(product){
  price = df$prices[match(x = product,table = df$products)]
  return(price)
}

getproductprice("table")







