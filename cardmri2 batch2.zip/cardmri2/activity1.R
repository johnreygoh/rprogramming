# activity 1
# construct a script:
#
# first name: jojo
# last name: gomez
# rate per hour: 800
# hours worked: 10
# less total deductions: 200
#
# jojo gomez, net pay: php7800
#
# operators + - * /
# f = ...
# l = ...
# rh = ...
# h = ...
# d = ...
# netp = (rh*h)-d
# paste0(f," ",l,", net pay: php",netp)

f = readline(prompt = "first name:")
l = readline(prompt = "last name:")
r = as.numeric(readline(prompt = "rate per hour:"))
h = as.numeric(readline(prompt = "hours:"))
d = as.numeric(readline(prompt = "total deduction:"))

np = (r * h) - d
print(paste0(f," ",l,", net pay: php",np))












