library(stringr)
# loop demo

# repeat an action, based on conditions
# while loop
c = 10
while(c <= 3){
  print(paste0(c,".hi there!"))
  c = c + 1

}

# do while
c2 = 10
repeat{
  
  print("good pm")
  c2 = c2 + 1

  if(c2>=5){
    break
  }

}


# for each
v = c(34,67,87,99)

for (i in v) {
  ans = i + 1000
  print(ans)
}

# vectorized operations
v2 = v + 1000
print(v2)

v3 = c("gina","marco","fiona","liam")
newv3 = NULL
# by looping
for (n in v3) {
  newv3 = append(newv3,str_to_upper(n))
}

print(newv3)

v3 = str_to_upper(v3)
print(v3)










