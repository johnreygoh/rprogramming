# list operations

# create
li1 = list(firstname="gina",lastname="santos",age=45)
li1

li1[[2]]
li1$age

# add
li1$address = "laguna"
li1$gender = "female"
li1

# edit
li1$gender = "male"
li1

# remove
li1$gender = NULL
li1

for (i in li1) {
  if (is.character(i)) {
    i = toupper(i)
  }
  print(i)
}

length(li1)


li2 = list(office="makati",telno=7665544)
li3 = list(li1,li2)
li3

li4 = c(li1,li2)
li4












