# getting input from user in console

n = readline(prompt = "Enter your name:")
b = readline(prompt = "Enter birth year:")
d = readline(prompt = "Enter department:")

# welcome dianne of hr dept! born: 1999
r = paste0("welcome ",n," of ",d," dept! born:",b)
print(r)


