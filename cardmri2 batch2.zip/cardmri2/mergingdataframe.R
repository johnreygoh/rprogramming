# merging dataframe

# join
# d1
# id  name  address
# 1   jojo  manila
# 2   ken   makati

# d2
# id  dept   position
# 1   mis    dev
# 2   hr     manager

ids = c(1,2,3)
names = c("alice","bob","leni")
addr = c("manila","makati","laguna")
dept = c("hr","mis","mis")
pos = c("manager","admin","developer")
df_emp = data.frame(id = ids,
                 names = names,
                 address = addr)

print(df_emp)

df_empwork = data.frame(id = ids,
                        department = dept,
                        position = pos)

print(df_empwork)

df_merged = cbind(df_emp,df_empwork[c("department","position")])
# df_merged = merge(df_emp,df_empwork,by.y = ids, all = T)
print(df_merged)


# union
d1 = data.frame(id = 1:3,
                names = c("alice","bob","leni"),
                salary = c(12000,14000,20000)
                )

d2 = data.frame(id = 4:6,
                names = c("bobby","steve","jamie"),
                salary = c(22000,24000,30000)
                )

# df_combined = merge(d1,d2,by=ids,all=T)
df_combined = rbind(d1,d2)
df_combined
