
# string r
# install.packages("stringr")
library(stringr)

s = "australia,israel "
trimmed = str_trim(s)
count = str_count(s)
counttrimmed = str_count(trimmed)
u = str_to_upper(s)
l = str_to_lower(s)
first3 = str_sub(s,start = 1,end = 3)
last3 = str_sub(s,start = counttrimmed-2,end = counttrimmed)
sp = str_split(s,pattern = ",")
sp[[1]][2]

rep = str_replace_all(s,pattern = "a",replacement = "e")
finding = str_detect(s,pattern = "israel")
