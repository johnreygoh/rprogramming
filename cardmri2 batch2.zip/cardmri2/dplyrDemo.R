# dplyr demo
library(dplyr)
df = read.csv("cardmri2/superstore.csv")

# select columns
dfcategorysales = df %>% select(Category,Sales)
head(dfcategorysales)

# filter and sort
dffurnituresales = df %>% 
  select(Region,Category,Sub.Category,Sales) %>%
  filter(Category=="Furniture" & Sales > 500) %>%
  arrange(Sub.Category,desc(Sales))

head(dffurnituresales)

# mutation (add computed column)
newdf = df %>%
  select(Region,Ship.Mode,Sales,Profit) %>%
  mutate(newprofit = ifelse(Region=="South",Profit+1000,Profit+2000))

head(newdf)

# grouping and summarization
dfshipmodereport = df %>%
  filter(Ship.Mode != "Same Day") %>%
  group_by(Ship.Mode) %>%
  summarise(
      totalsales = sum(Sales),
      averagesales = mean(Sales),
      totalprofit = sum(Profit),
      averageprofit = mean(Profit)
    )

dfshipmodereport$Ship.Mode = 
  gsub(" Class","",dfshipmodereport$Ship.Mode)

print(as.data.frame(dfshipmodereport))
class(as.data.frame(dfshipmodereport))



