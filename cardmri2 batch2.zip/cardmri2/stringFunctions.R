# string functions

s = "apple,banana,mango"

scount = nchar(s)
strim = trimws(s)
countnospaces = nchar(trimws(s))

u = toupper(s)
l = tolower(s)
sp = strsplit(s,split = ",")
secword = sp[[1]][2]

first3 = substr(s,1,3)
last3 = substr(s,nchar(s)-2,nchar(s))

repl = gsub("a","e",s) #replace
fi = grepl("man",s) #find






