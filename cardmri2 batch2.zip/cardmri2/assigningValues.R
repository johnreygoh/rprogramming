# assign values to variables

a = 4
b <- 5
6 -> c



