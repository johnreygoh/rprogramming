# data frame operations
# create from vectors

prodname = c("A","B","C","D")
sales = c(10000,15000,30000,NA)
profit = c(8000,9000,12000,NA)

df1 = data.frame(products=prodname,sales=sales,profit=profit)

df1

