# scatter plot
# library(ggplot2)

ages = c(10,12,14,16,17)
scores = c(99,97,94,89,76)

df = data.frame(age = ages,score = scores)

plot(x = df$age,
     y = df$score,
     main = "Age by Score",
     xlab = "Age",
     ylab = "Scores",
     col = "red"
    )



