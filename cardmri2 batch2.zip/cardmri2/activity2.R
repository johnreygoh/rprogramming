# activity2

# enter name: nino
# gender[m/f]: m
# civil status [s/m]: m
#
# hi mr.nino!     mr./mrs./miss

na = "henna"
ge = "f"
cs = "s"

t = ""
if (ge=="m") {
  t = "Mr."
}else if (ge=="f") {
  if (cs == "s"){
    t = "Miss "
  }else if (cs == "m") {
    t = "Mrs."
  }else{
    t = ""
  }
}else{
  t = ""
}

print(paste0("hi ",t,na,"!"))





