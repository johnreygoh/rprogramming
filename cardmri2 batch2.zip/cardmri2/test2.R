# this is how to concatenate values

# variables
fname = "Marian"
lname = "Rivera"
age = 36
# res = paste(fname,lname,age,sep = "-")
print
(
  paste0(
    fname,
    "-",
    lname,
    " ",
    age)
)

# chopping math expressions
# avoid starting new lines with operators
ans = 
  12 + 
  45 + 
  23
print(ans)










