# connect to mssql
# RODBC package

# install.packages("RODBC")
library(RODBC)

conn = odbcConnect("cardmri", uid = "sa", pwd = "123")
query = "SELECT * FROM employees"

df = sqlQuery(conn, query)
print(df)

odbcClose(conn)



