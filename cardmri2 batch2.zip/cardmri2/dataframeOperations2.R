# dataframe operations 2

vnames = c("alice","dina","rizza")
vages = c(45,44,34)
vsalary = c(10000,12000,13000)

df1 = data.frame(names = vnames,
                 ages = vages, 
                 salary = vsalary)

print(df1)

# built-in datasets
# to view
# data()
# df2 = Titanic
# str(df2)

# load dataset from csv
dft = read.csv("cardmri2/titanic.csv")
print(dft)

# increase max.print
options(max.print = 6000)

# check names
colnames(dft)

# view specific cols
dfsub = dft[c("Passenger.Name","Gender","Age")]

# viewing
head(dfsub)
tail(dfsub)

# summary
summary(dft)

# structure
str(dft)

# highest,lowest,average age
# ages = dft[c("Age")]
ages = dft$Age
class(ages)
head(ages)
tail(ages)

h = max(ages,na.rm = T)
l = min(ages,na.rm = T)
a = floor(mean(ages,na.rm = T))
print(paste0("highest age:",h))
print(paste0("lowest age:",l))
print(paste0("average age:",a))






