# data prep

# v1 = c("jane","tarzan","elsa","ana","olaf")
# v2 = c(34000,NA,78000,NA,77000)
# v3 = c("mis","hr","hr","mis",NA)
# 
# df = data.frame(names = v1,
#                 salary = v2,
#                 dept = v3)
df = read.csv("cardmri2/titanic.csv")

# handle missing values
# remove rows with missing values
# df = na.omit(df)
# df = df[complete.cases(df),] 

# impute values
# reconfirm, 0, mean, fillup, filldown
# df$names[is.na(df$names)] = "none"
# df$salary[is.na(df$salary)] = 0     # mean(df$salary)
# df$dept[is.na(df$dept)] = "none"

# loop all cols, handle missing values
for (col in colnames(df)) {

  x = df[[col]]
  if (is.numeric(x)) {
    df[[col]][is.na(x)] = 0
  }else{
    df[[col]][is.na(x) | is.null(x) | x == "" ] = "none"
  }

}

# data transformation
# passenger name uppercase
# df$Passenger.Name = toupper(df$Passenger.Name)
library(stringr)
df$Passenger.Name = str_to_upper(df$Passenger.Name)
# remove class in class / department
df$Class...Department = gsub("Class","",df$Class...Department)
# round off price
df$Price.in.British.Pounds = round(df$Price.in.British.Pounds,
                                   digits = 2)
# victim -> Deceased
df$Survived..[df$Survived.. == "Victim"] = "Deceased"

# remove punctuations
df$Age.Group = gsub("[[:punct:]]","",df$Age.Group)


# add column
df$AgeCategory = ifelse(df$Age>=16,"Adult","Young")


# remove extreme values (outliers) , whole row
# IQR InterQuantile Range
# age
q1 = quantile(df$Age,0.25)
q3 = quantile(df$Age,0.75)
IQR = q3 - q1
df = df[df$Age >= q1 - 1.5 * IQR & df$Age <= q3 + 1.5 * IQR,]


write.csv(x = df,
          file = "cardmri2/cleanedtitanic.csv",
          row.names = F)
















