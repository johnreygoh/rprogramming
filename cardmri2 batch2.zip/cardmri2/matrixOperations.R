# matrix operations
m1 = matrix(data = c(1,2,3,4,5,6),nrow = 2,ncol = 3)
m1

m1 = matrix(data = 1:100, 
            ncol = 10, 
            nrow = 10,
            dimnames = 
              list(
                c("r1","r2","r3","r4","r5","r6","r7","r8","r9","r10"),
                c("c1","c2","c3","c4","c5","c6","c7","c8","c9","c10")
              )
            )
m1

# accessing
m1[4,3] #row,col
m1[1,]
m1[,10]

m1

# row and functions
# matrixStats
library(matrixStats)
rowSums2(m1)
rowMeans2(m1)
rowMaxs(m1)
rowMins(m1)
rowMedians(m1)

colSums2(m1)
colMeans2(m1)
colMaxs(m1)
colMins(m1)
colMedians(m1)

m1

# filter and subset
# m1 = m1[rowMaxs(m1)==100]
m1 = matrix(m1[rowSums2(m1)<=500],nrow = 10, ncol = 10)
m1








