# dataframe practice1
# basic analytics
df = read.csv("cardmri2/superstore.csv")

# check summary
summary(df)

# check structure
str(df)

# check colnames
print(colnames(df))

# counting unique values
# shipmodes = df[c("Ship.Mode")]
shipmodes = df$Ship.Mode
print(length(shipmodes))
print(length(unique(shipmodes)))

cities = df$City
print(length(unique(cities)))

regions = unique(df$Region)
print(regions)

# sales desc
sales = df$Sales
print(paste0("total sales: ",round(sum(sales),digits = 2)))
print(paste0("average sales: ",round(mean(sales),digits = 2)))
print(paste0("max sales: ",max(sales)))
print(paste0("min sales: ",min(sales)))

# show only region, category, sales
dfsub1 = df[c("Region","Category","Sales")]
head(dfsub1)
length(dfsub1$Region)

df_south = dfsub1[dfsub1$Region == "South",]
length(df_south$Region)

df_west = dfsub1[dfsub1$Region == "West",]
length(df_west$Region)

df_sales500plus = dfsub1[dfsub1$Sales >= 500,]
length(df_sales500plus$Sales)

# basic aggregation and group
# total sales per region
agg1 = aggregate(df$Sales, by = list(df$Region), FUN = sum)
print(agg1)





