# package management

# to adjust options
# getOption("max.print")
# options(max.print = 1000000)

# view avail packages
# available.packages()

# install
install.packages("stringr")
install.packages("dplyr","lubridate","ggplot2")

# view installed
installed.packages()

# remove
remove.packages("stringr")

# load package
library(stringr)






