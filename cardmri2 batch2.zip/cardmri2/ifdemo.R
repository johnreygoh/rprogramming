# if demo
# relational operators
# == != > >= < <=
# connection
# & and, both sides true
# | or, at least or both must be true
# ! not, negate

# single if
# age = 19
# if (age <= 17) {
#   print("not ready to vote")
# }

# if else
# age = 56
# if (age <= 17) {
#   print("not ready to vote")
#   # actions
# }else{
#   print("ready to vote")
#   # actions
# }

# ternary
# age = 13
# ifelse(age>=18,"ready to vote","not ready to vote")

# if elseif else
# age <=3 : child
# age 4-7 : toddler
# age 8-12 : pre-teen
# age 13-19: teenager
# age 20+ :adult
# age = 8
# if (age <= 3) {
#   print("child")
# }else if(age >= 4 & age <=7){
#   print("toddler")
# }else if(age >= 8 & age <=12){
#   print("pre-teen")
# }else if(age >= 13 & age <=19){
#   print("teenager")
# }else{
#   print("adult")
# }

# age = 16
# if (age >= 20) {
#   print("adult")
# }else if(age >= 13){
#   print("teenager")
# }else if(age >= 8){
#   print("pre-teen")
# }else if(age >= 4){
#   print("toddler")
# }else{
#   print("child")
# }

# nested if
# 2 offices
# makati,am = ms80000, pm = ms85000
# laguna, am = ms90000, pm = ms95000
office = "laguna"
sch = "pm"
if(office=="makati"){
  if(sch=="am"){
    print("80000")
  }else{
    print("85000")
  }
}else if(office=="laguna"){
  if(sch=="am"){
    print("90000")
  }else{
    print("95000")
  }
}else{
  print("office not registered")
}
















