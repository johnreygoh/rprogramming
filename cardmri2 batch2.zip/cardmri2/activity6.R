# url = "https://raw.githubusercontent.com/johnreygoh/powerbiclass/master/orders.csv"
# df = read.csv(url)

df = read.csv("cardmri2/orders.csv")

colnames(df)
summary(df)

# activity:
# generate 3 csv reports shows the ff:

library(dplyr)
library(lubridate)
# productreport.csv (grouped)
# prodname  totalsales averagesales maxsales minsales totalprofit

dfproducts = df %>%
  group_by(Product.Name) %>%
  summarise(
    totalsales = sum(Sales),
    avgsales = mean(Sales),
    maxsales = max(Sales),
    minsales = min(Sales)
  )

dfproducts = as.data.frame(dfproducts)
write.csv(x = dfproducts, 
          file = "cardmri2/productreport.csv",
          row.names = F)


# customerreport.csv (grouped)
# customername  totalsales averagesales maxsales minsales totalprofit
dfcustomers = df %>%
  group_by(Customer.Name) %>%
  summarise(
    totalsales = sum(Sales),
    avgsales = mean(Sales),
    maxsales = max(Sales),
    minsales = min(Sales)
  )
dfcustomers = as.data.frame(dfcustomers)
write.csv(x = dfcustomers, 
          file = "cardmri2/customerreport.csv",
          row.names = F)

# daytodayreport.csv (grouped)
# orderdate(desc) totalsales totalprofit

df$Order.Date = mdy(df$Order.Date)
dfdaily = df %>%
  group_by(Order.Date) %>%
  summarise(
    totalsales = sum(Sales),
    totalprofit = sum(Profit)
  ) %>%
  arrange(desc(Order.Date))

write.csv(x = dfdaily,
          file = "cardmri2/daytodayreport.csv",
          row.names = F)









