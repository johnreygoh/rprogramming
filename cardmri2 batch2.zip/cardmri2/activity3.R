# activity3

# part1:
# print 1960->2023
# print 2023->1960
# part2:
# modify code, exclude 1980-1990
# part3:
# create a vector for each of the 2 sets
# v1 = NULL 
# v1 = append(v1,????)


y1 = 1960
v1 = NULL
while(y1<=2023){
  
  if(y1<1980 | y1>1990){
    print(y1)
    v1 = append(v1,y1)
  }
  
  y1 = y1 + 1
}
print(v1)




y2 = 2023
v2 = NULL
while(y2>=1960){
  if(y2<1980 | y2>1990){
    print(y2)
    v2 = append(v2,y2)
  }
  
  y2 = y2 - 1
}

print(v2)






