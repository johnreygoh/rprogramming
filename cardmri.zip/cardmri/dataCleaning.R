# data cleaning
prodnames = c("A",NA,"C","D","E","F","G","H","I","J")
quantity = c(10,20,30,NA,NA,NA,70,80,90,100)
price = c(120,220,220,340,NA,NA,800,340,200,700)

df = data.frame(products = prodnames,
                quantity = quantity,
                price = price)

df

# clean and transform -> save into a new csv
# remove rows with missing values
# df = na.omit(df)
# df
# df = df[complete.cases(df),]
# df

# impute missing values
# 0, mean(), fillup filldown
# df$quantity[is.na(df$quantity)] = mean(df$quantity,na.rm = T)
# df$price[is.na(df$price)] = 500
# df
# 
# # edit values
# df$price[df$price<500] = 450
# df
# 
# df$quantity = round(df$quantity,digits = 0)
# df
# 
# yearnow = year(today())
# df$products = tolower(paste0(df$products,"-",yearnow))
# df
# 
# # add computed column
# # price <= 500 , discount = 2%, else 4%
# df$discount = ifelse(df$price<=500,df$price*.02,df$price*.04)
# df
# 
# # remove punctuations
# df$greet = "hello, there!!!"
# df
# 
# df$greet = gsub("[[:punct:]]","",df$greet)
# df

# write to csv
#write.csv(df,file = "cardmri/cleaned1.csv")

# df[is.na(df)] = 0
# 
# df

# loop each col
for (col in colnames(df)) {
  x = df[[col]]
  if(is.numeric(x)){
    df[[col]][is.na(x) | is.null(x) | df[[col]]=="" ] = 0
  }else{
    df[[col]][is.na(x) | is.null(x) | df[[col]]=="" ] = "none"
    
    if (col=="Passenger.Name") {
      df[[col]] = toupper(df)
    }
  }
}

df








