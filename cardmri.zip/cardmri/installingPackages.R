#increase console output
options(max.print = 1000000)

#check packages
available.packages()

#install
install.packages("tidyr")

#install multiple
toadd=c("stringR","dplyr","ggplot")
install.packages(toadd)

#load package
library(dplyr)
library(stringr)

#remove
remove.packages(c("dplyr","stringr","ggplot2"))

#check installed packages
installed.packages()


