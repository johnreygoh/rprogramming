# activity1
# transactions

# form
# first name: ??????
# last name: ?????
# sales amount: ?????
# input another?[y/n]: ???

# first name    last name   sales amount
# henry         sy          80000
# fiona         shrek       67000
# george        bush        56000
#
#
# total sales: 203000


# repeat{
#   get input1
#   get input2
#   get input3
#   get input4
#   addtovector1()
#   addtovector2()
#   addtovector3()
#   if(input4=="n"){
#     break
#   }
# }
# 
# df = data.frame(fn=vector1,ln=vector2, sales=vector3)
# print(df)
# print(sum(vector3)


fn = ""
ln = ""
sa = 0
ag = ""
v1=NULL
v2=NULL
v3=NULL
repeat{
  fn = readline(prompt = "enter first name:")
  ln = readline(prompt = "enter last name:")
  sa = as.numeric(readline(prompt = "enter sales amount:"))
  ag = readline(prompt = "input another?[y/n]")
  v1=append(v1,fn)
  v2=append(v2,ln)
  v3=append(v3,sa)
  if (ag=="n") {
    break
  }
}
df = data.frame(first_name=v1,last_name=v2,sales_amount=v3)
print(df)
totsales = as.character(sum(v3))
print(paste0("Total Sales:", totsales))















