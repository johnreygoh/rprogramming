# list operations
l1 = list(name = "fina",age = 45)
print(l1)

print(l1["name"])
print(l1$name)

# list from variables
fn = "kevin"
ln = "cosme"
address = "riles"
age = 67
l2 = list(fn,ln,address,age,scores=c(45,46,67))
print(l2$scores[1])

l2$firstname = fn
l2$lastname = ln
l2$address = address
l2$age = age

l2$age = 80
print(l2)

# extracting
li3 = l2[c("firstname","lastname","address","age","scores")]
print(li3)

li3$telno = 6789999
print(li3)

li3$age = NULL
li3$telno = NULL
print(li3)

li4 = list()
class(li4)

























