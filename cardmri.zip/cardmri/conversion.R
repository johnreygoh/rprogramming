# explicit conversion / coercion
a = as.numeric("23")
# a = NULL
b = as.numeric("24")
c = a + b
print(c)
d = a - b
print(d)

# checking data type
is.character(a)
is.numeric(a)
is.na(a)
is.null(a)
