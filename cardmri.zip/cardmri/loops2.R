# for each
# get first 3 chars, convert to uppercase
offices = c("laguna","manila","cebu","baguio","pasig")
for (office in offices) {
  print(toupper(substr(office,1,3)))
}

