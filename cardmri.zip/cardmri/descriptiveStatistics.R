
# business intelligence
# descriptive analytics

# data analyst
# predictive analytics
# prescriptive analytics

# descriptive statistics
# category vs measure

# sum mean median mode count min max
# range, variance, standard deviation
# outliers
# percentile 25% 75%
# skewness base 3, high skw=incr freq, low skw=decr freq
# kurtosis base 3, high kur=spread out, low kur=norm distrib

df = read.csv("cardmri/titanic.csv")
ages = as.vector(unlist(df[c("Age")]))

sum_a = sum(ages,na.rm = T)
mean_a = round(mean(ages,na.rm = T),digits = 1)

# show freq of values
t = table(ages) #table
t_df = as.data.frame(table(ages)) #data frame

# mode
mode_a = names(sort(-table(ages)))[1]

max_a = max(ages,na.rm = T)
min_a = min(ages,na.rm = T)

count_a = length(ages)
count_uq_a = length(unique(ages))

# range, variance, sd
range_a = range(ages,na.rm = T)
var_a = var(ages,na.rm = T)
sd_a = sd(ages,na.rm = T)

# skew, kurtosis
library(moments)
skew_a = skewness(ages,na.rm = T)
kur_a = kurtosis(ages,na.rm = T)

summary(ages)






