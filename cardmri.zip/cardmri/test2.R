# concatenation of display
myname="johnny"
myage=22
print(paste("welcome",myname,myage,"yrs old",sep="_"))
print(paste0("welcome_",myname,"_",myage,"_yrs old"))