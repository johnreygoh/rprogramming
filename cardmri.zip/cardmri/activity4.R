# activity 4
# load titanic dataset -> clean 
# -> save as "cleaned titanic.csv"
# text cols na = "unknown"
# number cols na = 0
# date cols na = "unknown"
# passenger names = upper case
# survived? "yes" / "no"
library(stringr)

df = read.csv("cardmri/titanic.csv")
colnames(df)
summary(df)

# df$Age.Group[is.null(df$Age.Group) | is.na(df$Age.Group) | df$Age.Group==""] = "unknown"
# df$Age[is.na(df$Age)] = 0
# df$Passenger_Survived[is.null(df$Passenger_Survived) | is.na(df$Passenger_Survived) | df$Passenger_Survived==""] = "unknown"
# df$Class...Department[is.null(df$Class...Department) | is.na(df$Class...Department) | df$Class...Department==""] = "unknown"
# df$Crew.or.Passenger.[is.null(df$Crew.or.Passenger.) | is.na(df$Crew.or.Passenger.) | df$Crew.or.Passenger.==""] = "unknown"
# df$Disembarked.at[is.null(df$Disembarked.at) | is.na(df$Disembarked.at) | df$Disembarked.at==""] = "unknown"
# df$Embarked[is.null(df$Embarked) | is.na(df$Embarked) | df$Embarked==""] = "unknown"
# df$Home.Country[is.null(df$Home.Country) | is.na(df$Home.Country) | df$Home.Country==""] = "unknown"
# df$Job.details[is.null(df$Job.details) | is.na(df$Job.details) | df$Job.details==""] = "unknown"
# df$Job[is.null(df$Job) | is.na(df$Job) | df$Job==""] = "unknown"
# 
# df$Passenger.Name[
#   is.null(df$Passenger.Name) | 
#     is.na(df$Passenger.Name) | 
#     df$Passenger.Name==""] = "unknown"
# 
# df$Price.in.British.Pounds[is.null(df$Price.in.British.Pounds) | is.na(df$Price.in.British.Pounds) | df$Price.in.British.Pounds==""] = 0
# df$Profile.on.Encyclopedia.Titanica[is.null(df$Profile.on.Encyclopedia.Titanica) | is.na(df$Profile.on.Encyclopedia.Titanica) | df$Profile.on.Encyclopedia.Titanica==""] = "unknown"
# df$Survived..[is.null(df$Survived..) | is.na(df$Survived..) | df$Survived..==""] = "unknown"
# df$Ticket.Number[is.null(df$Ticket.Number) | is.na(df$Ticket.Number) | df$Ticket.Number==""] = "unknown"
# df$Year.of.Birth[is.null(df$Year.of.Birth) | is.na(df$Year.of.Birth) | df$Year.of.Birth==""] = "unknown"
# 
# library(stringr)
# df$Passenger.Name = str_to_upper(df$Passenger.Name)

# loop each col
for (col in colnames(df)) {
  x = df[[col]]
  if(is.numeric(x)){
    df[[col]][is.na(x) | is.null(x) | df[[col]]=="" ] = 0
  
  }else{
    
    df[[col]][is.na(x) | is.null(x) | df[[col]]=="" ] = "none"
    
    if (col=="Passenger.Name") {
      df[[col]] = str_to_upper(df[[col]])
    }

    if (col=="Survived..") {
      df[[col]] = ifelse(df[[col]]=="Survivor","Yes","No")
    }
  }
}

write.csv(df,file="cardmri/cleaned titanic.csv")









