# lubridate demo
library(lubridate)

t = today()

s = "2020-9-10 14:23"
date_s = ymd_hm(s)
year(date_s)
month(date_s)
day(date_s)
hour(date_s)
minute(date_s)

year(t)

bdate = as.Date(ymd("1997-1-24"))
currdate = as.Date(ymd("2023-10-4"))

# computation = days diff
i = as.numeric((currdate - bdate)/365)

# lubridate
lub_i = interval(start = bdate, end = currdate)
sec_diff = int_length(lub_i)
yeardiff = floor(((sec_diff/3600)/24)/365)

# get sec diff using base
yeardiff2 = floor(as.numeric(
  difftime(currdate,bdate,units = "days")/365
  ))

y1 = year(bdate)
y2 = year(currdate)
yeardiff3 = y2 - y1

print(currdate)

after5days = currdate + days(5)
print(after5days)

fivedaysbefore = currdate + days(-5)
print(fivedaysbefore)










