
# if condition
# > >= < <= == !=
# && and
# || or
# single
# age=19
# if (age>=18) {
#   print("ok to vote")
# }

# if else
# age = 12
# if (age>=18) {
#   print("ok to vote")
# }else{
#   print("not ok to vote")
# }

# multiple
# c = 13
# if (c>=80) {
#   print("dapat may kasama")
# }else if (c>=18) {
#   print("ok to vote")
# }else{
#   print("not ok to vote")
# }

# nested if
# Welcome miss/mrs/mr barbie!
# na = "barbie"
# ge = "mali"
# cs = "married"
# 
# tl = ""
# if (ge=="male") {
#   tl="Mr."
#   
# }else if (ge=="female") {
#     if (cs=="single") {
#       tl="Miss "
#     }else if (cs=="married") {
#       tl="Mrs."
#     }else{ 
#       tl="" 
#     }
# }else{
#   tl=""
# }
# 
# print(paste0("Welcome ",tl,na,"!"))

# quiz
# given a grade, output:
# PASSED (A+)
# 75+ passed | <75 failed
# A+ 97-100
# A- 94-96
# B+ 90-93
# B- 85-89
# C+ 80-84
# C- 75-79
# F <75
g = 76
p = ""
if (g>=75) {
  p="PASSED"
}else{
  p="FAILED"
}

eq = ""
if (g>=97) {
  eq = "A+"
}else if (g>=94) {
  eq="A-"
}else if (g>=90) {
  eq="B+"
}else if (g>=85) {
  eq="B-"
}else if (g>=80){
  eq="C+"
}else if (g>=75) {
  eq="C-"
}else{
  eq="F"
}

print(paste0(p," (",eq,")"))


















