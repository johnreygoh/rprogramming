# custom functions

greetme = function(firstname,lastname){

  fullname = toupper(paste0(firstname," ",lastname))
  greeting = paste0("Welcome ",fullname,"!")
  return(greeting)
  
}

greetme2 = function(firstname,lastname){
  
  fullname = toupper(paste0(firstname," ",lastname))
  greeting = paste0("Welcome ",fullname,"!")
  print(greeting)
  
}

getnetpay = function(msalary,months,sss=5000,pagibig=5000){
  
  np = (msalary*months) - (sss+pagibig)
  return(np)
  
}

sum_all = function(...){
  
  items = list(...)
  answer = sum(unlist(items))
  return(answer)
}








