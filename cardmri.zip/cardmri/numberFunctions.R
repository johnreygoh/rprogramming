# number functions
sales = c(9800,7600,4500,7800,6000,5000)
print(max(sales))
print(min(sales))
print(sum(sales))
print(median(sales))
print(mean(sales))
n=-5
print(abs(n))



