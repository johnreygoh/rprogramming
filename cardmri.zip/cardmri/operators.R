#operators demo
# + - / * %% ^
a = 5
b = 2
c = a%%b
print(c)
d = b^2
print(d)

# activity
ename = "jojo"
ratehr = 1000
hrs = 60
sss = 500
pagibig = 600
# output
# hi jojo! net pay: ????
np = (ratehr*hrs) - (sss+pagibig)
print(paste0("hi ",ename,"! net pay: ",np))





