# superstore dataset demo

df = read.csv("cardmri/superstore.csv")

head(df)
tail(df)

summary(df)
colnames(df)

# sales
col_sales = as.vector(unlist(df[c("Sales")]))
totsales = round(sum(col_sales),digits = 2)
avgsales = round(mean(col_sales),digits = 2)
maxsales = max(col_sales)
minsales = min(col_sales)

# profit
col_Profit = as.vector(unlist(df[c("Profit")]))
totProfit = round(sum(col_Profit),digits = 2)
avgProfit = round(mean(col_Profit),digits = 2)
maxProfit = max(col_Profit)
minProfit = min(col_Profit)

# how many ship modes?
col_shipmodes = as.vector(unlist(df[c("Ship.Mode")]))
uniq_cols = unique(col_shipmodes)
cnt_uniq_cols = length(uniq_cols)

# unique cities?
col_cities = as.vector(unlist(df[c("City")]))
uq_cities = unique(col_cities)
num_uq_cities = length(uq_cities)

# display on console regions
col_regions = as.vector(unlist(df[c("Region")]))
print(unique(col_regions))

#shipmode,sales,category [central]
#filter
options(max.print = 1000000)
central_res = df[df$Region=="Central",]
central_fcols = central_res[c("Category","Ship.Mode","Sales")]
central_fcols

# data frame write to csv
write.csv(central_fcols,file = "cardmri/centralsales.csv",row.names = F)

# quiz
# South region
# shipmode, category, subcategory, sales, profit
# northsales.csv

# sort 
# east region, sort highest sales first
# shipmode segment category sales

east_res = df[df$Region=="East",]
east_res_sorted = east_res[order(-east_res$Sales),] #descending
#east_res_sorted = east_res[order(east_res$Sales),] #ascending
east_df = east_res_sorted[c("Ship.Mode","Segment","Category","Sales")]
head(east_df)

# aggregation
aggre = aggregate(df$Sales,by = list(df$Region),FUN = sum)
print(aggre)

# total profit by category
tprofitbycat = aggregate(df$Profit,by = list(df$Category),FUN = sum)
print(tprofitbycat)





















